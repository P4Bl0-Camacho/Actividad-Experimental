
package com.mycompany.sistemagestionproyectos;

import java.util.ArrayList;
import java.util.List;

// Clase Tarea
class Tarea {
    public String nombre;
    public String descripcion;
    public boolean completada;

    public Tarea(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.completada = false;
    }

    public void completarTarea() {
        this.completada = true;
    }

    public String getEstado() {
        return completada ? "Completada" : "Pendiente";
    }

    @Override
    public String toString() {
        return "Tarea: " + nombre + " | Descripcion: " + descripcion + " | Estado: " + getEstado();
    }
}

// Clase Proyecto
class Proyecto {
    public String nombre;
    public List<Tarea> tareas;

    public Proyecto(String nombre) {
        this.nombre = nombre;
        this.tareas = new ArrayList<>();
    }

    public void agregarTarea(Tarea tarea) {
        tareas.add(tarea);
    }

    public void mostrarEstado() {
        System.out.println("Proyecto: " + nombre);
        for (Tarea tarea : tareas) {
            System.out.println(tarea);
        }
    }
}

public class SistemaGestionProyectos {
    public List<Proyecto> proyectos;

    public SistemaGestionProyectos() {
        this.proyectos = new ArrayList<>();
    }

    public void registrarProyecto(String nombre) {
        proyectos.add(new Proyecto(nombre));
        System.out.println("Proyecto '" + nombre + "' registrado con exito.");
    }

    public Proyecto obtenerProyecto(String nombre) {
        for (Proyecto proyecto : proyectos) {
            if (proyecto.nombre.equals(nombre)) {
                return proyecto;
            }
        }
        return null;
    }

    public void mostrarProyectos() {
        System.out.println("Lista de proyectos:");
        for (Proyecto proyecto : proyectos) {
            System.out.println("- " + proyecto.nombre);
        }
    }

    public static void main(String[] args) {
        SistemaGestionProyectos sistema = new SistemaGestionProyectos();

        // Registrar proyectos
        sistema.registrarProyecto("Proyecto 1");
        sistema.registrarProyecto("Proyecto 2");

        // Obtener un proyecto y asignar tareas
        Proyecto proyecto1 = sistema.obtenerProyecto("Proyecto 1");
        if (proyecto1 != null) {
            proyecto1.agregarTarea(new Tarea("Diseño", "Crear el diseño inicial del sistema"));
            proyecto1.agregarTarea(new Tarea("Implementacion", "Desarrollar las funcionalidades principales"));
        }

        Proyecto proyecto2 = sistema.obtenerProyecto("Proyecto 2");
        if (proyecto2 != null) {
            proyecto2.agregarTarea(new Tarea("Investigacion", "Investigar tecnologias para el proyecto"));
        }

        // Mostrar estado de los proyectos
        sistema.mostrarProyectos();
        if (proyecto1 != null) proyecto1.mostrarEstado();
        if (proyecto2 != null) proyecto2.mostrarEstado();
    }
}
